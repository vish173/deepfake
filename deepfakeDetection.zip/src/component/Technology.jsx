import React from 'react';

const Technology = () => {
  return (
    <div className="technology">
      <h1>Technology Stack</h1>
      <p>
        The Deepfake Image Detection System leverages a modern technology stack to provide accurate and efficient detection of deepfake images. Below are the key technologies used in this project:
      </p>
      <h2>Front-end</h2>
      <h3>ReactJS</h3>
      <p>
        ReactJS is a popular JavaScript library for building user interfaces, especially single-page applications. It allows for efficient rendering and updating of components, making it an ideal choice for this project.
      </p>
      <h2>Back-end</h2>
      <h3>Python</h3>
      <p>
        Python is a versatile programming language that is widely used in machine learning and data science. It provides the backbone for the backend of this system.
      </p>
      <h3>TensorFlow</h3>
      <p>
        TensorFlow is an open-source machine learning framework developed by Google. It is used in this project to build and train the deep learning models that detect deepfake images.
      </p>
      <h3>OpenCV</h3>
      <p>
        OpenCV (Open Source Computer Vision Library) is a powerful library of programming functions for real-time computer vision. It is used in this project for image processing tasks.
      </p>
    </div>
  );
};

export default Technology;
