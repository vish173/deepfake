import React, { useState } from 'react';
import axios from 'axios';

const FileUpload = () => {
  const [file, setFile] = useState(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [deepfakePercentage, setDeepfakePercentage] = useState(null);

  const handleFileUpload = (e) => {
    const uploadedFile = e.target.files[0];
    setFile(uploadedFile);

    // Simulate file upload progress
    let progress = 0;
    const interval = setInterval(() => {
      progress += 10;
      setUploadProgress(progress);

      if (progress >= 100) {
        clearInterval(interval);
        setTimeout(() => {
          setUploadProgress(0);
          analyzeDeepfakeContent(uploadedFile);
        }, 1000);
      }
    }, 500);
  };

  const analyzeDeepfakeContent = async (file) => {
    try {
      const formData = new FormData();
      formData.append('image', file); 

      const response = await axios.post('http://localhost:5000/deepfake-detection', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        },
        onUploadProgress: (progressEvent) => {
          const percentCompleted = Math.round((progressEvent.loaded * 100) / progressEvent.total);
          setUploadProgress(percentCompleted);
        }
      });

      
      if (response.data && response.data.deepfake_percentage !== undefined) {
        setDeepfakePercentage(response.data.deepfake_percentage);
      }
    } catch (error) {
      console.error('Error analyzing deepfake content:', error);
    }
  };

  return (
    <div className="upload-container">
      <p className="message">Step 1: Upload the image you want to analyze for deepfake content</p>
      <p>Supported formats: Image (PNG, JPEG)</p>

      <label htmlFor="file-upload" className="upload-button">
        Upload File
      </label>
      <input
        type="file"
        accept="image/png, image/jpeg"
        id="file-upload"
        onChange={handleFileUpload}
      />

      {file && (
        <div className="file-details">
          <p>Filename: {file.name}</p>
          <p>File Type: {file.type}</p>
          <p>File Size: {file.size} bytes</p>
        </div>
      )}

      {uploadProgress > 0 && uploadProgress < 100 && (
        <div className="progress">
          <div
            className="progress-bar"
            style={{ width: `${uploadProgress}%` }}
          >
            {uploadProgress}%
          </div>
        </div>
      )}

      {deepfakePercentage !== null && (
        <div className="success-message">
          <p>Deepfake Probability: {deepfakePercentage}%</p>
        </div>
      )}

      <div className="steps-container">
        <p className="step">Step 1: Upload your image for deepfake analysis</p>
        <p className="step">Step 2: Wait for the analysis to complete</p>
        <p className="step">Step 3: Review the deepfake probability and take necessary actions</p>
      </div>
    </div>
  );
};

export default FileUpload;
