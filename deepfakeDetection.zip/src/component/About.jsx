import React from 'react';

const AboutUs = () => {
  return (
    <div className="about-us">
      <h1>About Us</h1>
      <h2>Project Title</h2>
      <p>Deep Learning Based Deepfake Detection</p>
      <h2>Group Members</h2>
      <ul>
        <li>Vivek Mahajan - C43392</li>
        <li>Vishal Waghmare - C42335</li>
        <li>Sushant Jogdand - C43385</li>
        <li>Ashwin Wani - C42327</li>
      </ul>
    </div>
  );
};

export default AboutUs;
