import React from 'react';

const Overview = () => {
  return (
    <div className="overview">
      <h1>Deepfake Image Detection System</h1>
      <p>
        Welcome to the Deepfake Image Detection System. This application allows
        you to upload images and determine whether they have been manipulated
        using deepfake technology. Deepfake images are artificially generated or
        altered using advanced AI algorithms, making them look real even though
        they are not.
      </p>
      <h2>How It Works</h2>
      <ol>
        <li>Upload an image using the file upload feature.</li>
        <li>
          The system processes the image using a sophisticated deepfake detection
          algorithm.
        </li>
        <li>The result will indicate whether the image is real or fake.</li>
      </ol>
      <h2>Why Use This System?</h2>
      <p>
        Deepfake technology has advanced significantly, making it increasingly
        difficult to distinguish between real and fake images. This system helps
        identify deepfake images, ensuring the authenticity of visual content.
      </p>
    </div>
  );
};

export default Overview;
