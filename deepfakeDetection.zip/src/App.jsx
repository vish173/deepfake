// App.js
import React, { useState } from "react";
import "./App.css";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import FileUpload from "./component/FileUpload";
import About from "./component/About";
import Home from "./component/Home";
import Overview from "./component/Overview";
import Technology from "./component/Technology";
import Navbar from "./component/Navbar";
import Login from "./component/Login";
import SignUp from "./component/SignUp";

const App = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  return (
    <Router>
      <Navbar isLoggedIn={isLoggedIn} setIsLoggedIn={setIsLoggedIn} />
      <div className="App">
        <Routes>
          <Route path="/Home" element={<Home />} />
          <Route path="/About" element={<About />} />
          <Route path="/overview" element={<Overview />} />
          <Route path="/technology" element={<Technology />} />
          <Route path="/upload" element={<FileUpload />} />
          <Route path="/login" element={<Login setIsLoggedIn={setIsLoggedIn} />} />
          <Route path="/signup" element={<SignUp />} />
          <Route path="/" element={<Home />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
